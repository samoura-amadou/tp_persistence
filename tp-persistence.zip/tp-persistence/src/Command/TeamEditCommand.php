<?php

namespace App\Command;
use App\Repository\TeamRepository ;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Style\SymfonyStyle;

#[AsCommand(
    name: 'team:edit',
    description: 'modify',
)]
class TeamEditCommand extends Command
{
    private $entityManager ;
    private $teamRepository ;

    public function __construct(
        EntityManagerInterface $entityManager,
        TeamRepository $teamRepository,
        string $name = null)
    {
        parent::__construct($name);
        $this->entityManager=$entityManager ;
        $this->teamRepository=$teamRepository;
    }

    protected function configure(): void
    {
        $this
            ->addOption('teamName', null, InputOption::VALUE_REQUIRED, 'Option description')

        ;
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $io = new SymfonyStyle($input, $output);

        $teamName = $input->getOption('teamName') ;
        $team = $this->teamRepository->find($teamName) ;


        if($team){
            $teamName = $io->ask('nouveau nom : ', $team->getName()) ;
            $team->setName($teamName) ;

        }else {
            $io->error('port doesnt exist') ;
            return Command::FAILURE ;
        }
        $this->entityManager->persist($team);
        $this->entityManager->flush();

        $io->success('You have a new command! Now make it your own! Pass --help to see your options.');

        return Command::SUCCESS;
    }
}
