<?php

namespace App\Command;
use App\Repository\TeamRepository ;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Style\SymfonyStyle;

#[AsCommand(
    name: 'team:list',
    description: 'Add a short description for your command',
)]
class TeamListCommand extends Command
{
    private $teamRepository ;

    public function __construct(TeamRepository $teamRepository, string $name = null)
    {
        parent::__construct($name);
        $this->teamRepository = $teamRepository ;
    }

    protected function configure(): void
    {
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $io = new SymfonyStyle($input, $output);
        $teams = $this->teamRepository->findAll() ;

        $table= new Table($output);
        $table->setHeaders(['Id','Name','City','Color']);

        foreach ($teams as $team) {
            $table ->addRow([$team->getId(),$team->getName(), $team->getCity(),$team->getColor()]) ;
        }
        $table->render() ;
        return Command::SUCCESS;
    }
}
