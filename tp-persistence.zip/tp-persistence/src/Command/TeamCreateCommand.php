<?php

namespace App\Command;
use App\Repository\TeamRepository ;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Style\SymfonyStyle;

#[AsCommand(
    name: 'team:create',
    description: 'Add a short description for your command',
)]
class TeamCreateCommand extends Command
{
    private $entityManager ;
    public function __construct(EntityManagerInterface $entityManager,string $name = null)
    {
        parent::__construct($name);
        $this->entityManager = $entityManager ;
    }
    protected function configure(): void
    {
        $this
            ->addOption('teamId', null,InputOption::VALUE_REQUIRED, 'team id')
            ->addOption('teamName', null,InputOption::VALUE_REQUIRED, 'team name')
            ->addOption('teamCity', null, InputOption::VALUE_REQUIRED, 'team city')
            ->addOption('teamColor', null, InputOption::VALUE_REQUIRED, 'team color')

        ;
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $io = new SymfonyStyle($input, $output);
        $teamId='' ;
        if ($input->getOption('teamId')) {
            $competitionName=$input->getOption('teamId') ;
            // ...
        }

        $teamName='' ;
        if ($input->getOption('teamName')) {
            $competitionName=$input->getOption('teamName') ;
            // ...
        }
        $teamCity='' ;
        if ($input->getOption('teamCity')) {
            $competitionName=$input->getOption('teamCity') ;
            // ...
        }

        $teamColor='' ;
        if ($input->getOption('teamColor')) {
            $competitionName=$input->getOption('teamColor') ;
            // ...
        }


        

        $team=new Team ();

        $teamId->setName($teamId);
        $teamName->setName($teamName);
        $teamCity->setName($teamCity);
        $teamColor->setName($teamColor);


        $this->entityManager->persist($team);
        $this->entityManager->flush();

        $io->success('You have a new command! Now make it your own! Pass --help to see your options.');

        return Command::SUCCESS;
    }
}
